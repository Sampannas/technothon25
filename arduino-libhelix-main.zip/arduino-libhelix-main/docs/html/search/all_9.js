var searchData=
[
  ['removeinvaliddata_16',['removeInvalidData',['../classlibhelix_1_1_common_helix.html#a06fb5c57ba1b3ba1604f6a9230a92f8b',1,'libhelix::CommonHelix']]],
  ['resynch_17',['resynch',['../classlibhelix_1_1_common_helix.html#afb501010c3d53d97373a428df6fd582e',1,'libhelix::CommonHelix']]]
];
