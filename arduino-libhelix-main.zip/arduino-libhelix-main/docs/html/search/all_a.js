var searchData=
[
  ['setaudioinfo_18',['setAudioInfo',['../classlibhelix_1_1_a_a_c_decoder_helix.html#abdfad65dca1bff4b7d7d82566540d0fd',1,'libhelix::AACDecoderHelix']]],
  ['setmaxframesize_19',['setMaxFrameSize',['../classlibhelix_1_1_common_helix.html#a28a81c90298d1dbc107b2b799ce3fed2',1,'libhelix::CommonHelix']]],
  ['setmaxpcmsize_20',['setMaxPCMSize',['../classlibhelix_1_1_common_helix.html#ad81283a33815f2c1b915a4c00393e22d',1,'libhelix::CommonHelix']]],
  ['setminframebuffersize_21',['setMinFrameBufferSize',['../classlibhelix_1_1_common_helix.html#a843186aabc424e76ca263145917640d5',1,'libhelix::CommonHelix']]],
  ['setreference_22',['setReference',['../classlibhelix_1_1_common_helix.html#a48a996faa5a49aa6c397c62c3731a978',1,'libhelix::CommonHelix']]]
];
