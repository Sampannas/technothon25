var searchData=
[
  ['timeoflastresult_23',['timeOfLastResult',['../classlibhelix_1_1_common_helix.html#ab3030ef3ef276399001b76e968497c59',1,'libhelix::CommonHelix']]],
  ['timeoflastwrite_24',['timeOfLastWrite',['../classlibhelix_1_1_common_helix.html#a95968d071da149606db651c2dbf336af',1,'libhelix::CommonHelix']]]
];
