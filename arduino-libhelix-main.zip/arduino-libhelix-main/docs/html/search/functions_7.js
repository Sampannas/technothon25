var searchData=
[
  ['presync_41',['presync',['../classlibhelix_1_1_common_helix.html#afbc0bbf7315f02725bf8df20cc620c26',1,'libhelix::CommonHelix']]]
];
